package com.boukouch.mini_projet.model

data class Note (val id :Int , val title:String , val content :String){

}
